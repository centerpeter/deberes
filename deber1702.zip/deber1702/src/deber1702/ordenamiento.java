 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package deber1702;

import java.util.Scanner;

/**
 *
 * @author Pedro
 */
public class ordenamiento {
    
    public static void main(String[] args) {
        int arr[]=new int[5];
        Scanner sc = new Scanner (System.in);
        for(int i=0; i<arr.length;i++)
        {
            System.out.println("introduzca un numero");
            arr[i]=sc.nextInt();
        }
        System.out.println("los numeros en orden inverso son");
        int j=4;
        while(j>=0)
            
        {
            System.out.println(""+arr[j]+"");
            j--; //j=311
        }
        
}}
